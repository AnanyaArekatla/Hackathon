/**
 * 
 */
/**
 * 
 */
module CampusClicks {
}